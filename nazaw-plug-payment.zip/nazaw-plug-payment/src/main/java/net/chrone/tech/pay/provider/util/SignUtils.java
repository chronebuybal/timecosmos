package net.chrone.tech.pay.provider.util;

import java.util.Map;
import java.util.TreeMap;

import com.google.common.base.Strings;

public class SignUtils {

    public static String signData(Map<String, String> tempMap, String priKey) throws Exception {
        StringBuffer buf = new StringBuffer();
        for (String key : tempMap.keySet()) {
            if (Strings.isNullOrEmpty(tempMap.get(key))) {
                continue;
            }
            buf.append(key).append("=").append(tempMap.get(key)).append("&");
        }
        buf.setLength(buf.length() - 1);
        System.out.println("签名字符串:" + buf.toString());
        String signData = null;
        signData = RSAUtil.signByPrivate(buf.toString(), priKey, "UTF-8");
        return signData;
    }

    public static boolean verferSignData(TreeMap<String, String> tempMap, String pukKey) {
        StringBuffer buf = new StringBuffer();
        for (String key : tempMap.keySet()) {
            if (Strings.isNullOrEmpty(tempMap.get(key))) {
                continue;
            }
            if ("signature".equals(key)) {
                continue;
            }
            buf.append(key).append("=").append(tempMap.get(key)).append("&");
        }
        buf.setLength(buf.length() - 1);
        return RSAUtil.verify(buf.toString(), tempMap.get("signature"), pukKey, "UTF-8");
    }

}
