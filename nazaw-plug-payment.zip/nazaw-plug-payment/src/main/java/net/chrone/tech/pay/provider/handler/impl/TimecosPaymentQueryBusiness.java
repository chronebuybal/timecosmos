package net.chrone.tech.pay.provider.handler.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;

import net.chrone.tech.pay.provider.handler.PaymentBusinessHandler;
import net.chrone.tech.pay.provider.spi.PaymentProvider;
import net.chrone.tech.pay.provider.util.HttpClientHelper;
import net.chrone.tech.pay.provider.util.SdkUtil;

public class TimecosPaymentQueryBusiness extends PaymentProvider implements PaymentBusinessHandler {

    private static final Logger log = LoggerFactory.getLogger(TimecosPaymentQueryBusiness.class);

    @Override
    public Map<String, Object> doBusiness(Map<String, Object> reqMap) {
        try {
            log.info("query TimecosmosPay Start:" + reqMap.get("orderNo"));
            Map<String, String> map = new HashMap<>();
            map.put("token",""+reqMap.get("mchntKey"));
            map.put("txnid", "" + reqMap.get("orderNo"));
            log.info("query TimecosmosPay req:" + JSON.toJSONString(map));
            String responseData = HttpClientHelper.doPost(SdkUtil.getStringValue("TimecosmosPaymentQueryUrl"),
					JSON.toJSONString(map));            		
            log.info("query TimecosmosPay res:" + responseData);

            if (StringUtils.isEmpty(responseData)) {
                return null;
            }
            Map<String, Object> responseMap = JSON.parseObject(responseData, Map.class);
            Map<String, Object> resMap = new HashMap<>();
            String status = "PENDING";
            if ("Paid".equals(responseMap.get("Status") + "")) {
                status = "TXN_SUCCESS";
            }
            resMap.put("status", status);
            if (null != responseMap.get("Amount")) {
                resMap.put("amount", responseMap.get("Amount"));
            }
            if(null!=responseMap.get("RRN"))resMap.put("bankTxnId", responseMap.get("RRN"));
            resMap.put("reqJson", responseData);
            log.info("TimecosmosPay end" + reqMap.get("orderNo"));
            return resMap;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
