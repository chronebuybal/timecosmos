package net.chrone.tech.pay.provider;

import net.chrone.tech.pay.provider.domain.IpInfo;

/**
 * 支付服务
 * 
 * @author biyan	
 *
 */
public interface IpProvider {

	public IpInfo getProvByIp(String ip);

}
