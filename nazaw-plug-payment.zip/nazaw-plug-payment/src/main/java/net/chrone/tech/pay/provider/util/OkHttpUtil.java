package net.chrone.tech.pay.provider.util;


import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;

import lombok.extern.slf4j.Slf4j;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.ConnectionPool;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author chenxinyao
 * @date 2019/12/18 22:13
 */
@Slf4j
public class  OkHttpUtil {

    private static OkHttpClient okHttpClient = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS).writeTimeout(20, TimeUnit.SECONDS)
        .connectionPool(new ConnectionPool(100, 5, TimeUnit.MINUTES)).retryOnConnectionFailure(true)
        .hostnameVerifier(new AllowAllHostnameVerifier())
        .build();
    


    /**
     * post请求 application/json; charset=utf-8
     *
     * @param url
     * @param headers
     * @param params
     * @return
     */
    public static String postJson(String url, Headers headers, String params) {
        Response response = null;
        try {
            long start = System.currentTimeMillis();
            response = okHttpClient.newCall(buildPostRequest(url, headers, params)).execute();
            String body = response.body().string();
            log.info("postJson url:{} param:{} headers:{} response:{} time:{}", url, params,
                headers == null ? null : headers.toString(), body, System.currentTimeMillis() - start);
            // if (response.isSuccessful()) {
            return body;
            // }
        } catch (Exception e) {
            log.error("OkHttpTemplate.postJson url:{} params:{} error ", url, params, e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    /**
     * put请求
     *
     * @param url
     * @param headers
     * @param params
     * @return
     */
    public static String putJson(String url, Headers headers, String params) {
        Response response = null;
        try {
            long start = System.currentTimeMillis();
            response = okHttpClient.newCall(buildPutRequest(url, headers, params)).execute();
            String body = response.body().string();
            log.info("postJson url:{} param:{} headers:{} response:{} time:{}", url, JSON.toJSONString(params),
                headers == null ? null : headers.toString(), body, System.currentTimeMillis() - start);
            // if (response.isSuccessful()) {
            return body;
            // }
        } catch (Exception e) {
            log.error("OkHttpTemplate.postJson params:{} error:{}", params, e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    /**
     * post请求返回指定对象
     *
     * @param url
     * @param headers
     * @param params
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T postJson(String url, Headers headers, String params, Class<T> clazz) {
        String response = postJson(url, headers, params);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        System.out.println("response------------"+response);
        return JSONObject.parseObject(response, clazz);
    }

    /**
     * post请求返回指定对象 支持泛型
     *
     * @param url
     * @param headers
     * @param params
     * @param type
     * @param <T>
     * @return
     */
    public static <T> T postJson(String url, Headers headers, String params, TypeReference<T> type) {
        String response = postJson(url, headers, params);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        return JSONObject.parseObject(response, type);
    }

    /**
     * put请求返回指定对象
     *
     * @param url
     * @param headers
     * @param params
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T putJson(String url, Headers headers, String params, Class<T> clazz) {
        String response = putJson(url, headers, params);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        return JSONObject.parseObject(response, clazz);
    }

    public static <T> T putJson(String url, Headers headers, String params, TypeReference<T> type) {
        String response = putJson(url, headers, params);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        return JSONObject.parseObject(response, type);
    }

    public static void postJsonAsync(String url, Headers headers, String params) {
        Call call = okHttpClient.newCall(buildPostRequest(url, headers, params));
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                log.error("OkHttpTemplate.postJsonAsync failed param:{} error:{}", params, e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                log.info("OkHttpTemplate.postJsonAsync success param:{},response:{}", params, response.body().string());
            }
        });

    }

    public static String get(String url, Headers headers) {
        Response response = null;
        try {
            response = okHttpClient.newCall(buildGetRequest(url, headers, null)).execute();
            String body = response.body().string();
            log.info("get failed url:{} response:{}", url, body);
            if (response.isSuccessful()) {
                return body;
            }
        } catch (Exception e) {
            log.error("OkHttpTemplate.get url:{} error:", url, e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    /**
     * get 请求返回指定类型
     *
     * @param url
     * @param headers
     * @param type
     * @param <T>
     * @return
     */
    public static <T> T get(String url, Headers headers, TypeReference<T> type) {
        String response = get(url, headers);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        log.info("url:{} response:{}", url, response);
        return JSONObject.parseObject(response, type);
    }

    /**
     * get 请求返回指定类型
     *
     * @param url
     * @param headers
     * @param tClass
     * @param <T>
     * @return
     */
    public static <T> T get(String url, Headers headers, Class<T> tClass) {
        String response = get(url, headers);
        log.info("url:{} response:{}", url, response);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        return JSONObject.parseObject(response, tClass);
    }

    /**
     * 表单提交
     *
     * @param url
     * @param param
     * @return
     */
    public static String formPost(String url, Map<String, String> param) {
        return formPost(url, null, param);
    }

    /**
     * 返回指定类型
     *
     * @param url
     * @param headerMap
     * @param param
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T formPost(String url, Map<String, String> headerMap, Map<String, String> param, Class<T> clazz) {
        String response = formPost(url, headerMap, param);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        return JSONObject.parseObject(response, clazz);
    }

    /**
     * 返回指定类型
     *
     * @param url
     * @param headerMap
     * @param param
     * @param type
     * @param <T>
     * @return
     */
    public static <T> T formPost(String url, Map<String, String> headerMap, Map<String, String> param,
        TypeReference<T> type) {
        String response = formPost(url, headerMap, param);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        return JSONObject.parseObject(response, type);
    }

    /**
     * get表单提交返回指定类型
     *
     * @param url
     * @param headerMap
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T formGet(String url, Map<String, String> headerMap, Class<T> clazz) {
        String response = formGet(url, headerMap);
        if (StringUtils.isEmpty(response)) {
            return null;
        }
        return JSONObject.parseObject(response, clazz);
    }

    /**
     * 表单提交
     *
     * @param url
     * @param headerMap
     * @param param
     * @return
     */
    public static String formPost(String url, Map<String, String> headerMap, Map<String, String> param) {
        OkHttpClient okHttpClient = new OkHttpClient();

        FormBody.Builder builder = new FormBody.Builder();
        if (!CollectionUtils.isEmpty(param)) {
            param.forEach((k, v) -> {
                builder.add(k, v);
            });
        }
        RequestBody body = builder.build();
        Request.Builder requestBuilder =
            new Request.Builder().url(url).header("Content-Type", "application/x-www-form-urlencoded").post(body);
        if (!CollectionUtils.isEmpty(headerMap)) {
            headerMap.forEach((k, v) -> {
                requestBuilder.header(k, v);
            });
        }
        Call call = okHttpClient.newCall(requestBuilder.build());
        Response response = null;
        try {
            response = call.execute();
            String responseBody = response.body().string();
            log.info("formPost url:{} param:{} responseBody:{}", url, JSON.toJSONString(param), responseBody);
            return responseBody;
        } catch (IOException e) {
            log.error("OkHttpUtil.formPost failed url:{} param:{}", url, JSON.toJSONString(param), e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    /**
     * get 表单提交
     *
     * @param url
     * @param headerMap
     * @return
     */
    public static String formGet(String url, Map<String, String> headerMap) {
        OkHttpClient okHttpClient = new OkHttpClient();

        Request.Builder requestBuilder =
            new Request.Builder().url(url).header("Content-Type", "application/x-www-form-urlencoded").get();
        if (!CollectionUtils.isEmpty(headerMap)) {
            headerMap.forEach((k, v) -> {
                requestBuilder.header(k, v);
            });
        }
        Call call = okHttpClient.newCall(requestBuilder.build());
        Response response = null;
        try {
            response = call.execute();
            String responseBody = response.body().string();
            log.info("formPost url:{} headerMap:{} responseBody:{}", url, JSON.toJSONString(headerMap), responseBody);
            return responseBody;
        } catch (IOException e) {
            log.error("OkHttpUtil.formPost failed url:{} ", url, e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    private static Request buildPostRequest(String url, Headers headers, String params) {
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json;charset=UTF-8"),
            ObjectUtils.defaultIfNull(params, ""));
        Request.Builder builder = new Request.Builder().url(url).post(requestBody);
        if (Objects.nonNull(headers)) {
            builder.headers(headers);
        }
        return builder.build();
    }

    private static Request buildPutRequest(String url, Headers headers, String params) {
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json;charset=UTF-8"),
            ObjectUtils.defaultIfNull(params, ""));
        Request.Builder builder = new Request.Builder().url(url).put(requestBody);
        if (Objects.nonNull(headers)) {
            builder.headers(headers);
        }
        return builder.build();
    }

    private static Request buildGetRequest(String url, Headers headers, Map<String, String> params) {
        Request.Builder builder = new Request.Builder();
        if (!CollectionUtils.isEmpty(params)) {
            HttpUrl httpUrl = HttpUrl.parse(url);
            HttpUrl.Builder urlBuilder = httpUrl.newBuilder();
            for (String key : params.keySet()) {
                urlBuilder.addQueryParameter(key, params.get(key));
            }
            builder.url(urlBuilder.build());
        } else {
            builder.url(url);
        }
        if (Objects.nonNull(headers)) {
            builder.headers(headers);
        }
        return builder.build();
    }

}
