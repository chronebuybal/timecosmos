package net.chrone.tech.pay.provider.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.ssl.OpenSSL;

public class AES256Util {


	 public static String encryptEncode(String plainStr, final String key) {
	        String encryptedRequest = "";
	        try {
	            InputStream stream = new ByteArrayInputStream(plainStr.getBytes());
	            encryptedRequest = getStringFromInputStream(OpenSSL.encrypt("AES256",
	                    key.getBytes(), stream, true));

	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (GeneralSecurityException e) {
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return replaceNewLine(encryptedRequest);
	    }

	    public static String decryptDecode(String cipherText, final String key) {
	        String decryptRequest = "";

	        //Log.e("AES", "cipherText :" + cipherText + " :: key " + key);

	        try {
	            decryptRequest = cipherText;
	            InputStream streamDec = new ByteArrayInputStream(decryptRequest.getBytes());
	            decryptRequest = getStringFromInputStream(OpenSSL.decrypt("AES256", key.getBytes(),
	                    streamDec));

	           // Logger.addLog("After Decryption :: " + decryptRequest);
	            //Log.e("AES", "decrypted :" + decryptRequest);
	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (GeneralSecurityException e) {
	            e.printStackTrace();
	        }

	        return decryptRequest;
	    }


	    //TODO :Shridhar dinde :Add Below fun for to convert InputStream to String....
	    private static String getStringFromInputStream(InputStream is) {
	        BufferedReader br = null;
	        StringBuilder sb = new StringBuilder();
	        BufferedInputStream bis = new BufferedInputStream(is);
	        ByteArrayOutputStream buf = new ByteArrayOutputStream();

	        String line = "";
	        try {

	            int result = bis.read();
	            while (result != -1) {
	                buf.write((byte) result);
	                result = bis.read();
	            }
	            line = buf.toString("UTF-8");


	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            if (br != null) {
	                try {
	                    br.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	        }

	        return line;

	    }
	    
	    
	    public static String replaceNewLine(String encrypted) {
	        return encrypted.replaceAll("(?:\\r\\n|\\n\\r|\\n|\\r)", "");
	    }
	    
	    
	    public static String calculateSHA256(String input) {
	        try {
	            MessageDigest digest = MessageDigest.getInstance("SHA-256");

	            byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));

	            StringBuilder hexString = new StringBuilder();
	            for (byte hashByte : hashBytes) {
	                String hex = Integer.toHexString(0xff & hashByte);
	                if (hex.length() == 1) {
	                    hexString.append('0');
	                }
	                hexString.append(hex);
	            }

	            return hexString.toString();

	        } catch (NoSuchAlgorithmException e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	    
	    
	    public static String calculateSHA128(String encryptedStr, String secretKey) {
	        try {
	            byte[] encryptedBytes = Base64.getDecoder().decode(encryptedStr);
	            SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "AES");
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
	            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
	            return new String(decryptedBytes, "UTF-8");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }
	   
	    
	    public static String encrypt(String plainText, String key, String iv) {
	        try {
	            byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
	            byte[] ivBytes = iv.getBytes(StandardCharsets.UTF_8);

	            SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");
	            IvParameterSpec ivParameterSpec = new IvParameterSpec(ivBytes);

	            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
	            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);

	            byte[] encryptedBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
	            return Base64.getEncoder().encodeToString(encryptedBytes);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	    
	    public static String decrypt(byte[] input, String key, String iv) {
	        try {
	            SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
	            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv.getBytes(StandardCharsets.UTF_8));

	            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
	            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);

	            byte[] decryptedBytes = cipher.doFinal(input);
	            return new String(decryptedBytes, StandardCharsets.UTF_8);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	    
	    public static String encryptSHAString(String input, String key) {
	        try {
	            MessageDigest digest = MessageDigest.getInstance("SHA-256");
	            byte[] keyBytes = key.getBytes("UTF-8");
	            digest.update(keyBytes);
	            byte[] hash = digest.digest(input.getBytes("UTF-8"));

	            StringBuilder hexString = new StringBuilder();
	            for (byte b : hash) {
	                String hex = Integer.toHexString(0xff & b);
	                if (hex.length() == 1) {
	                    hexString.append('0');
	                }
	                hexString.append(hex);
	            }

	            return hexString.toString();
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	
	    

	    public static String encryptString(String input, String key) {
	        try {
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), "AES");
	            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	            byte[] encryptedBytes = cipher.doFinal(input.getBytes());
	            return Base64.getEncoder().encodeToString(encryptedBytes);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }

	    public static String decryptString(String encryptedInput, String key) {
	        try {
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), "AES");
	            cipher.init(Cipher.DECRYPT_MODE, secretKey);

	            byte[] decodedBytes = Base64.getDecoder().decode(encryptedInput);
	            byte[] decryptedBytes = cipher.doFinal(decodedBytes);
	            return new String(decryptedBytes);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }

}