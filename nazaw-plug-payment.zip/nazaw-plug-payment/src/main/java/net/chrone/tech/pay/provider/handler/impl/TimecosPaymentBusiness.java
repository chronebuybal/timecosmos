package net.chrone.tech.pay.provider.handler.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import net.chrone.tech.pay.provider.handler.PaymentBusinessHandler;
import net.chrone.tech.pay.provider.spi.PaymentProvider;
import net.chrone.tech.pay.provider.util.AES256Util;
import net.chrone.tech.pay.provider.util.DateUtils;
import net.chrone.tech.pay.provider.util.OkHttpUtil;
import okhttp3.Headers;

public class TimecosPaymentBusiness extends PaymentProvider implements PaymentBusinessHandler {

    private static final Logger log = LoggerFactory.getLogger(TimecosPaymentBusiness.class);

    @Override
    public Map<String, Object> doBusiness(Map<String, Object> reqMap) {
        try {
            log.info("request Timecosmos payment start" + reqMap.get("orderNo"));
            Map<String, String> map = new HashMap<>();
            map.put("source","SQUIS-5189");
            map.put("channel", "api");
            map.put("extTransactionId", "" + reqMap.get("orderNo"));
            map.put("sid",""+reqMap.get("merId") );
            map.put("terminalId", ""+reqMap.get("terminalId"));
            map.put("amount", "" + reqMap.get("amount"));
            map.put("type", "D");
            map.put("remark", "QRtesting");
            map.put("requestTime", DateUtils.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
            map.put("minAmount", "1.00");
            map.put("receipt", "https://www.nazow.in/payin/callback");
            StringBuffer enStr = new StringBuffer();
            if(null!=map.get("source"))enStr.append(map.get("source"));
            if(null!=map.get("channel"))enStr.append(map.get("channel"));
            if(null!=map.get("extTransactionId"))enStr.append(map.get("extTransactionId"));
            if(null!=map.get("sid"))enStr.append(map.get("sid"));
            if(null!=map.get("terminalId"))enStr.append(map.get("terminalId"));
            if(null!=map.get("amount"))enStr.append(map.get("amount"));
            if(null!=map.get("type"))enStr.append(map.get("type"));
            if(null!=map.get("remark"))enStr.append(map.get("remark"));
            if(null!=map.get("requestTime"))enStr.append(map.get("requestTime")); 
            if(null!=map.get("minAmount"))enStr.append(map.get("minAmount"));
            if(null!=map.get("receipt"))enStr.append(map.get("receipt"));
            log.info("Timecosmos checkSum Before encry Str:" + JSON.toJSONString(map));
            map.put("CheckSum",AES256Util.encryptSHAString(enStr.toString(),""+reqMap.get("priKey")));
            log.info("Timecosmos before encryption json :" + JSON.toJSONString(map));
            String json = AES256Util.encryptString( JSON.toJSONString(map),""+reqMap.get("mchntKey"));
            log.info("Timecosmos req:" + JSON.toJSONString(map));
			JSONObject responseData=OkHttpUtil.postJson("https://merchantuat.timepayonline.com/evok/qr/v1/dqr", 
					initHeader(""+reqMap.get("merId"),""+reqMap.get("pubKey")), 
					json,
					JSONObject.class);
            log.info("Timecosmos res：" + responseData);
            if (null==responseData) {
                return null;
            }
             Map<String, Object> resMap = new HashMap<>();
            resMap.put("action", "");
            resMap.put("upi", responseData.get("UPI_URL"));
            log.info("request Timecosmos payment end" );
            return resMap;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    

    private Headers initHeader(String merchantId,String pubKey) {
    	Map<String,String> headerMap=new HashMap<>();
    	headerMap.put("Content-Type", "application/json");
    	headerMap.put("cid", pubKey);
    	log.info("headers:"+headerMap);
    	return Headers.of(headerMap);
    }
    
    public static void main(String[] args) {
    	TimecosPaymentBusiness timecosPaymentBusiness = new TimecosPaymentBusiness();
    	Map<String, Object> reqMap = new HashMap();
    	reqMap.put("orderNo","SQUISHY20231221007" );
    	reqMap.put("amount","100.00" );
    	reqMap.put("merId","SQUIS5189" );
    	reqMap.put("mchntKey","6858e49efee008142697ab1b9d8acb37" );
    	reqMap.put("priKey","6858e49efee008142697ab1b9d8acb37" );
    	reqMap.put("pubKey","52ef9ce8fa942ab8ee0fe556b26356b2" );
    	reqMap.put("terminalId", "SQUIS-5189");
    	timecosPaymentBusiness.doBusiness(reqMap);
	}
    
    
}
