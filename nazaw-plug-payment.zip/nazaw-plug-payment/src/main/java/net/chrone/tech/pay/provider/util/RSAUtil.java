package net.chrone.tech.pay.provider.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Enumeration;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.util.Base64Utils;

/**
 * RSA 加密算法
 *
 * @author sujianfei
 */
public class RSAUtil {
	public static final String KEY_ALGORITHM = "RSA";//加密算法
	public static final String SIGN_SHA1_WITH_RSA = "SHA1WithRSA";
	public static final String SIGN_MD5_WITH_RSA = "MD5withRSA";
	public static final String SIGN_ALGORITHM_SHA256 = "SHA256WithRSA";
	static {
		if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
			Security.addProvider(new BouncyCastleProvider());
		}
	}

	/**
	 * RSA签名
	 *
	 * @param content       待签名数据
	 * @param input_charset 编码格式
	 * @return 签名值
	 * @throws UnsupportedEncodingException
	 */
	public static String signByPublic(String content, String publicKeyByte, String input_charset, String transformation)
			throws Exception {
		PublicKey publicKey = getPublicKey(publicKeyByte);
		return sign(content, input_charset, publicKey, transformation);
	}

	public static String signByPublic(String content, PublicKey publicKey, String input_charset, String transformation)
			throws Exception {
		return sign(content, input_charset, publicKey, transformation);
	}

	private static String sign(String content, String input_charset, Key key, String transformation)
			throws UnsupportedEncodingException, Exception {
		Cipher cipher;
		try {
			// Security.addProvider(new
			// org.bouncycastle.jce.provider.BouncyCastleProvider());
			cipher = Cipher.getInstance(transformation);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] output = cipher.doFinal(content.getBytes(input_charset));
			return Base64.encode(output);
		} catch (NoSuchAlgorithmException e) {
			throw new Exception("无此加密算法");
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
			return null;
		} catch (InvalidKeyException e) {
			throw new Exception("加密公钥非法,请检查");
		} catch (IllegalBlockSizeException e) {
			throw new Exception("明文长度非法");
		} catch (BadPaddingException e) {
			throw new Exception("明文数据已损坏");
		}
	}

	public static String signByPrivate(String content, PrivateKey privateKey, String input_charset) throws Exception {
		if (privateKey == null) {
			throw new Exception("加密私钥为空, 请设置");
		}
		java.security.Signature signature = java.security.Signature.getInstance(SIGN_SHA1_WITH_RSA);
		signature.initSign(privateKey);
		signature.update(content.getBytes(input_charset));
		return Base64.encode(signature.sign());
	}

	public static String signMd5WithRsaByPrivate(String content, PrivateKey privateKey, String input_charset)
			throws Exception {
		if (privateKey == null) {
			throw new Exception("加密私钥为空, 请设置");
		}
		java.security.Signature signature = java.security.Signature.getInstance(SIGN_MD5_WITH_RSA);
		signature.initSign(privateKey);
		signature.update(content.getBytes(input_charset));
		return Base64.encode(signature.sign());
	}

	
	/**
	 * 数字签名
	 * @param data
	 * @param privateKey
	 * @return
	 * @throws Exception
	 */
	public static String sign(byte[] data, String privateKey,String algorithm) throws Exception {
        byte[] keyBytes = Base64Utils.decodeFromString(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        PrivateKey privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Signature signature = Signature.getInstance(algorithm);
        signature.initSign(privateK);
        signature.update(data);
        return Base64Utils.encodeToString(signature.sign());
    }
	
	/**
	 * 签名
	 * @param key	私钥
	 * @param requestData	请求参数
	 * @return
	 */
	public static String sign(String key, String requestData){
		String signature = null;
		byte[] signed = null;
		try {
			PrivateKey privateKey = getPrivateKey(key);
	        
			Signature Sign = Signature.getInstance("SHA256withRSA");
			Sign.initSign(privateKey);
			Sign.update(requestData.getBytes());
			signed = Sign.sign();
	        
			signature =Base64Utils.encodeToString(signed);
			System.out.println("===签名结果："+signature);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return signature;
	}
	public static String signByPrivate(String content, String privateKey, String input_charset) throws Exception {
		if (privateKey == null) {
			throw new Exception("加密私钥为空, 请设置");
		}
		PrivateKey privateKeyInfo = getPrivateKey(privateKey);
		return signByPrivate(content, privateKeyInfo, input_charset);
	}

	public static String encByPrivate(String context, Key privateKey, String transcation) throws Exception {
		// 对数据加密
		Cipher cipher = Cipher.getInstance(transcation, new org.bouncycastle.jce.provider.BouncyCastleProvider());
		cipher.init(Cipher.ENCRYPT_MODE, privateKey);
		InputStream ins = new ByteArrayInputStream(context.getBytes());
		ByteArrayOutputStream writer = new ByteArrayOutputStream();
		// rsa解密的字节大小最多是128，将需要解密的内容，按128位拆开解密
		byte[] buf = new byte[1024];
		int bufl;
		while ((bufl = ins.read(buf)) != -1) {
			byte[] block = null;

			if (buf.length == bufl) {
				block = buf;
			} else {
				block = new byte[bufl];
				for (int i = 0; i < bufl; i++) {
					block[i] = buf[i];
				}
			}
			writer.write(cipher.doFinal(block));
		}
		System.out.println(Arrays.toString(writer.toByteArray()));
		return Base64.encode(writer.toByteArray());
	}

	public static String encByPrivateNoProvider(String context, Key privateKey, String transcation) throws Exception {
		// 对数据加密
		Cipher cipher = Cipher.getInstance(transcation);
		cipher.init(Cipher.ENCRYPT_MODE, privateKey);
		InputStream ins = new ByteArrayInputStream(context.getBytes());
		ByteArrayOutputStream writer = new ByteArrayOutputStream();
		// rsa解密的字节大小最多是128，将需要解密的内容，按128位拆开解密
		byte[] buf = new byte[1024];
		int bufl;
		while ((bufl = ins.read(buf)) != -1) {
			byte[] block = null;

			if (buf.length == bufl) {
				block = buf;
			} else {
				block = new byte[bufl];
				for (int i = 0; i < bufl; i++) {
					block[i] = buf[i];
				}
			}
			writer.write(cipher.doFinal(block));
		}
		System.out.println(Arrays.toString(writer.toByteArray()));
		return Base64.encode(writer.toByteArray());
	}

	/**
	 * RSA验签名检查
	 *
	 * @param content       待签名数据
	 * @param sign          签名值
	 * @param publicKey     支付宝公钥
	 * @param input_charset 编码格式
	 * @return 布尔值
	 */
	public static boolean verify(String content, String sign, String publicKey, String input_charset) {
		try {
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			byte[] encodedKey = Base64.decode(publicKey);
			PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));
			return verify(content, sign, pubKey, input_charset);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public static boolean verifyMd4WithRsa(String content, String sign, PublicKey publicKey, String inputCharset) {
		try {
			java.security.Signature signature = java.security.Signature.getInstance(SIGN_MD5_WITH_RSA);
			signature.initVerify(publicKey);
			signature.update(content.getBytes(inputCharset));
			boolean bverify = signature.verify(Base64.decode(sign));
			return bverify;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean verify(String content, String sign, PublicKey publicKey, String inputCharset) {
		try {
			java.security.Signature signature = java.security.Signature.getInstance(SIGN_SHA1_WITH_RSA);
			signature.initVerify(publicKey);
			signature.update(content.getBytes(inputCharset));
			boolean bverify = signature.verify(Base64.decode(sign));
			return bverify;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean verify(byte[] content, byte[] sign, PublicKey publicKey, String inputCharset) {
		try {
			java.security.Signature signature = java.security.Signature.getInstance(SIGN_SHA1_WITH_RSA);
			signature.initVerify(publicKey);
			signature.update(content);
			boolean bverify = signature.verify(sign);
			return bverify;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 解密
	 *
	 * @param content       密文
	 * @param private_key   商户私钥
	 * @param input_charset 编码格式
	 * @return 解密后的字符串
	 */
	public static String decryptByPrivate(String content, String private_key, String input_charset) throws Exception {
		PrivateKey prikey = getPrivateKey(private_key);
		return decrypt(content, input_charset, prikey);
	}

	public static String decryptByPrivate(String content, PrivateKey privateKey, String input_charset,
			String transformation) throws Exception {
		return decrypt(content, input_charset, privateKey, transformation, 128);
	}

	private static String decrypt(String content, String input_charset, Key key)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException,
			IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, NoSuchProviderException {
		return decrypt(content, input_charset, key, "RSA/NONE/PKCS1Padding", 128);
	}

	public static String decrypt(String content, String input_charset, Key key, String transformation, int contentSize)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException,
			IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, NoSuchProviderException {
		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.DECRYPT_MODE, key);
		InputStream ins = new ByteArrayInputStream(Base64.decode(content));

		ByteArrayOutputStream writer = new ByteArrayOutputStream();
		// rsa解密的字节大小最多是128，将需要解密的内容，按128位拆开解密
		byte[] buf = new byte[contentSize];
		int bufl;
		while ((bufl = ins.read(buf)) != -1) {
			byte[] block = null;

			if (buf.length == bufl) {
				block = buf;
			} else {
				block = new byte[bufl];
				for (int i = 0; i < bufl; i++) {
					block[i] = buf[i];
				}
			}
			writer.write(cipher.doFinal(block));
		}
		return new String(writer.toByteArray(), input_charset);
	}

	public static String decrypt(String content, String input_charset, Key key, String transformation)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException,
			IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, NoSuchProviderException {
		ByteArrayOutputStream bout = null;
		try {
			Cipher cipher = Cipher.getInstance(transformation,
					Security.getProvider(BouncyCastleProvider.PROVIDER_NAME));
			byte[] contextByte = Base64.decode(content);
			cipher.init(Cipher.DECRYPT_MODE, key);
			int j = 0;
			int blockSize = cipher.getBlockSize();
			bout = new ByteArrayOutputStream();
			while (contextByte.length - j * blockSize > 0) {
				if (contextByte.length - j * blockSize < blockSize) {
					bout.write(cipher.doFinal(contextByte, j * blockSize, contextByte.length - j * blockSize));
				} else {
					bout.write(cipher.doFinal(contextByte, j * blockSize, blockSize));
				}
				j++;
			}
			return new String(bout.toByteArray(), input_charset);
		} finally {
			bout.close();
		}
	}

	public static String decryptNoProvider(String content, String input_charset, Key key, String transformation,
			int contentSize) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException,
			IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, NoSuchProviderException {
		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.DECRYPT_MODE, key);
		InputStream ins = new ByteArrayInputStream(Base64.decode(content));

		ByteArrayOutputStream writer = new ByteArrayOutputStream();
		// rsa解密的字节大小最多是128，将需要解密的内容，按128位拆开解密
		byte[] buf = new byte[contentSize];
		int bufl;
		while ((bufl = ins.read(buf)) != -1) {
			byte[] block = null;

			if (buf.length == bufl) {
				block = buf;
			} else {
				block = new byte[bufl];
				for (int i = 0; i < bufl; i++) {
					block[i] = buf[i];
				}
			}
			writer.write(cipher.doFinal(block));
		}
		return new String(writer.toByteArray(), input_charset);
	}

	public static String decryptByPublic(String content, String publicKey, String input_charset) throws Exception {
		PublicKey pubKey = getPublicKey(publicKey);
		return decrypt(content, input_charset, pubKey);
	}

	/**
	 * 得到私钥
	 *
	 * @param key 密钥字符串（经过base64编码）
	 * @throws Exception
	 */
	public static PrivateKey getPrivateKey(String key) throws Exception {
		byte[] keyBytes = buildPKCS8Key(key);
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
		return privateKey;
	}

	private static byte[] buildPKCS8Key(String privateKey) throws IOException {
		if (privateKey.contains("-----BEGIN PRIVATE KEY-----")) {
			return Base64.decode(privateKey.replaceAll("-----\\w+ PRIVATE KEY-----", ""));
		} else if (privateKey.contains("-----BEGIN RSA PRIVATE KEY-----")) {
			final byte[] innerKey = Base64.decode(privateKey.replaceAll("-----\\w+ RSA PRIVATE KEY-----", ""));
			final byte[] result = new byte[innerKey.length + 26];
			System.arraycopy(Base64.decode("MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKY="), 0, result, 0, 26);
			System.arraycopy(BigInteger.valueOf(result.length - 4).toByteArray(), 0, result, 2, 2);
			System.arraycopy(BigInteger.valueOf(innerKey.length).toByteArray(), 0, result, 24, 2);
			System.arraycopy(innerKey, 0, result, 26, innerKey.length);
			return result;
		} else {
			return Base64.decode(privateKey);
		}
	}

	public static KeyInfo getKeyInfoByPFXStr(String pfxStr, String password) throws KeyStoreException,
			NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableKeyException {
		// FileInputStream fis = new FileInputStream(pfxPath);
		InputStream fis = new ByteArrayInputStream(Base64.decode(pfxStr));
		KeyStore ks = KeyStore.getInstance("PKCS12");
		ks.load(fis, password.toCharArray());
		fis.close();
		Enumeration<String> enumas = ks.aliases();
		String keyAlias = null;
		if (enumas.hasMoreElements())// we are readin just one certificate.
		{
			keyAlias = enumas.nextElement();
		}

		KeyInfo keyInfo = new KeyInfo();

		PrivateKey prikey = (PrivateKey) ks.getKey(keyAlias, password.toCharArray());
		Certificate cert = ks.getCertificate(keyAlias);
		PublicKey pubkey = cert.getPublicKey();

		keyInfo.privateKey = prikey;
		keyInfo.publicKey = pubkey;
		return keyInfo;
	}

	public static class KeyInfo {

		PublicKey publicKey;
		PrivateKey privateKey;

		public PublicKey getPublicKey() {
			return publicKey;
		}

		public PrivateKey getPrivateKey() {
			return privateKey;
		}
	}

	/**
	 * <p>
	 * 公钥加密
	 * </p>
	 *
	 * @param data      源数据
	 * @param publicKey 公钥(BASE64编码)
	 * @return
	 * @throws Exception
	 */
	public static String encryptByPublicKey(byte[] data, String publicKey) throws Exception {
		byte[] keyBytes = Base64.decode(publicKey);
		X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		Key publicK = keyFactory.generatePublic(x509KeySpec);
		// 对数据加密
		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
		cipher.init(Cipher.ENCRYPT_MODE, publicK);
		int inputLen = data.length;
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int offSet = 0;
		byte[] cache;
		int i = 0;
		// 对数据分段加密
		while (inputLen - offSet > 0) {
			if (inputLen - offSet > 117) {
				cache = cipher.doFinal(data, offSet, 117);
			} else {
				cache = cipher.doFinal(data, offSet, inputLen - offSet);
			}
			out.write(cache, 0, cache.length);
			i++;
			offSet = i * 117;
		}
		byte[] encryptedData = out.toByteArray();
		out.close();
		return Base64.encode(encryptedData);
	}

	/**
	 * <p>
	 * 公钥加密
	 * </p>
	 *
	 * @param data      源数据
	 * @param publicKey 公钥(BASE64编码)
	 * @return
	 * @throws Exception
	 */
	public static String encryptByPublicKey(byte[] data, PublicKey publicKey, String cipherAlgorithm) throws Exception {
		// 对数据加密
		Cipher cipher = Cipher.getInstance(cipherAlgorithm);
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		int inputLen = data.length;
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int offSet = 0;
		byte[] cache;
		int i = 0;
		// 对数据分段加密
		while (inputLen - offSet > 0) {
			if (inputLen - offSet > 117) {
				cache = cipher.doFinal(data, offSet, 117);
			} else {
				cache = cipher.doFinal(data, offSet, inputLen - offSet);
			}
			out.write(cache, 0, cache.length);
			i++;
			offSet = i * 117;
		}
		byte[] encryptedData = out.toByteArray();
		out.close();
		return Base64.encode(encryptedData);
	}

	public static PublicKey getPublicKey(String key) throws Exception {
		if (key == null) {
			throw new Exception("加密公钥为空, 请设置");
		}
		byte[] buffer = Base64.decode(key);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
		return keyFactory.generatePublic(keySpec);
	}

	public static String getKey(String content) throws Exception {
		return content.replaceAll("\\-{5}[\\w\\s]+\\-{5}[\\r\\n|\\n]", "");
	}

	public static boolean verifyByKeyPath(String content, String sign, String publicKeyPath, String input_charset) {
		try {
			return verify(content, sign, getKey(publicKeyPath), input_charset);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 私钥加密
	 * 
	 * @param data
	 * @param privateKey
	 * @return
	 */
	public static String encryptByPrivate(String data, RSAPrivateKey privateKey) {
		try {
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(Cipher.ENCRYPT_MODE, privateKey);
			byte[] bytes = rsaSplitCodec(cipher, Cipher.ENCRYPT_MODE, data.getBytes("UTF-8"),
					privateKey.getModulus().bitLength());
			return org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(bytes);
		} catch (Exception e) {
			throw new RuntimeException("私钥加密字符串[" + data + "]时异常", e);
		}
	}

	/**
	 * 私钥加密
	 * 
	 * @param data       源
	 * @param privateKey 私钥
	 * @return
	 */
	public static String encryptByPrivate(String data, String privateKey) {
		try {
			// 获取私钥
			RSAPrivateKey rsaPrivateKey = getPrivateKey1(privateKey);
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(Cipher.ENCRYPT_MODE, rsaPrivateKey);
			return org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(rsaSplitCodec(cipher,
					Cipher.ENCRYPT_MODE, data.getBytes("UTF-8"), rsaPrivateKey.getModulus().bitLength()));
		} catch (Exception e) {
			throw new RuntimeException("私钥加密字符串[" + data + "]时异常", e);
		}
	}

	/**
	 * 得到私钥
	 * 
	 * @param privateKey 密钥字符串（经过base64编码）
	 * @throws Exception
	 */
	public static RSAPrivateKey getPrivateKey1(String privateKey)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		// 通过PKCS#8编码的Key指令获得私钥对象
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(
				org.apache.commons.codec.binary.Base64.decodeBase64(privateKey));
		RSAPrivateKey key = (RSAPrivateKey) keyFactory.generatePrivate(pkcs8KeySpec);
		return key;
	}

	/**
	 * 数据分段加密
	 * 
	 * @param cipher
	 * @param opmode
	 * @param datas
	 * @param keySize
	 * @return
	 * @throws Exception
	 */
	private static byte[] rsaSplitCodec(Cipher cipher, int opmode, byte[] datas, int keySize) throws Exception {
		int maxBlock = 0;
		if (opmode == Cipher.DECRYPT_MODE) {
			maxBlock = keySize / 8;
		} else {
			maxBlock = keySize / 8 - 11;
		}

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int offSet = 0;
		byte[] buff;
		int i = 0;
		byte[] resultDatas = null;
		try {
			while (datas.length > offSet) {
				if (datas.length - offSet > maxBlock) {
					buff = cipher.doFinal(datas, offSet, maxBlock);
				} else {
					buff = cipher.doFinal(datas, offSet, datas.length - offSet);
				}
				out.write(buff, 0, buff.length);
				i++;
				offSet = i * maxBlock;
			}
			resultDatas = out.toByteArray();
		} catch (Exception e) {
			throw new RuntimeException("加解密阀值为[" + maxBlock + "]的数据时发生异常", e);
		} finally {
			out.close();
		}
		return resultDatas;
	}

	public static void main(String[] args) {
		String s = "fnXYa6I+7puV9qdNwbDjYsKPc16jZQp19ieaGpWKeFHCMz4D6nDGH+do4gqYYVaxCD678HxYHG34g0+8nHAsFcvPivrtPzKNkQqvTEynw5uKtGZZQWcsyazA9Qgm1McycG68GuFtvwrDPUR/Z/IwhT/uxy0NmA957Xeca734/WBd3a8bkNxoW1ufW7QBtlwdCbncxlQRPZRGamd1nQghQvVnfqSmlX7FVcr5u9S22bpMHWMutZCf0zf8Af4mIll0p01P8P22ioBbOcC3QeBcCJSfgy7vu+DbP82j0GmqTf/iUYpYmh5MqCvEJqFmTKtlgt9txWJ3ruRdzOedoUC57g==";

		System.out.println(verify("ssss", s,
				"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAq1N5CSK9vti0h9tLufOEm4HLd5/F5NwhjABLzpzqdSEoJPVTf0hNsViqdCSAvtPMd0zZDCUHou8TcUd+RAm3C6GnSQQN6OQBYbah2zfKQw8h0f4NU4Pjidgu6WL0nBynJGsIRQNupqXE6gWtlFjNBLjKOChDoXG00IUQ7JUIUWP+8Rp7u4FrsQTgdlLVi/Z6XH6inlfpjSg2yKYGhHLixdq+7qo84nS/+aBcLUAvlbURDnOOI9DmnguTpUbddGnu7mRoD7Ztni4WtUIsxSDXCPXqifhFjRjlgUnwoBZWy5HDiQxKc7CdLLkUCGvSq4+cd7wHcsaNLAQ/Iah9Uj4J8wIDAQAB",
				"utf-8"));
	}

}
