package net.chrone.tech.pay.provider;

import java.util.Map;

/**
 * 支付服务
 * 
 * @author biyan	
 *
 */
public interface PayProvider {

	public Map<String,Object> doPaymentService(Map<String,Object> reqMap);

}
