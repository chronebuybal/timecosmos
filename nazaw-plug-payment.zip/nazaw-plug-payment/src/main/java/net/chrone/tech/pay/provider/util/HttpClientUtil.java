package net.chrone.tech.pay.provider.util;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.bouncycastle.jcajce.provider.symmetric.util.IvAlgorithmParameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;

/**
 * @descr:
 * @author: wangkc
 * @time: 2021年9月10日 下午4:09:00
 */
public class HttpClientUtil {
    private static final Logger LOG = LoggerFactory.getLogger(HttpClientUtil.class);
    private static final int CONNECTTIMEOUT = 60000;
    private static final int SOCKETTIMEOUT = 60000;
    private static final int CONNECTIONREQUESTTIMEOUT = 60000;
    private static final Charset CHARSET = StandardCharsets.UTF_8;

    // static CloseableHttpClient clientxx = HttpClients.createDefault();

    public static String doPostJSON(String urlStr, String json, Map<String, String> headerMap) throws Exception {
        return HttpClientUtil.doPostJSON(urlStr, json, headerMap, CONNECTTIMEOUT, SOCKETTIMEOUT);
    }

    public static String doPostJSON(String urlStr, String json, Map<String, String> headerMap, int connectTimeout, int socketTimeout) throws Exception {

        CloseableHttpResponse response = null;
        //CloseableHttpClient client = HttpClients.createDefault();
        CloseableHttpClient client = getClient();
        HttpPost httpPost = new HttpPost(urlStr);
        try {
            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(connectTimeout)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(socketTimeout).build();
            httpPost.setConfig(requestConfig);

            // 创建参数队列
            if (StringUtils.isNotBlank(json)) {

                StringEntity stringEntity = new StringEntity(json, CHARSET);
                stringEntity.setContentType("application/json");
                httpPost.setEntity(stringEntity);
            }
            //header
            if (MapUtils.isNotEmpty(headerMap)) {
                for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                    httpPost.setHeader(entry.getKey(), entry.getValue());
                }
            }

            response = client.execute(httpPost);

            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } catch (Exception e) {
            LOG.error("HttpClientUtil doPostJSON ERROR ,msg = " + e.getMessage(), e);
            throw e;
        } finally {
            if (response != null) {
                LOG.debug("CLOSE RESPONSE.");
                response.close();
            }
        }
        return "";
    }

    public static String doPostParam(String urlStr, Map<String, String> paramMap, Map<String, String> headerMap) throws Exception {
        return HttpClientUtil.doPostParam(urlStr, paramMap, headerMap, CONNECTTIMEOUT, SOCKETTIMEOUT);
    }

    /**
     * @param urlStr
     * @param paramMap
     * @param headerMap
     * @param connectTimeout
     * @param socketTimeout
     * @return
     * @throws Exception
     */
    public static String doPostParam(String urlStr, Map<String, String> paramMap, Map<String, String> headerMap, int connectTimeout, int socketTimeout) throws Exception {

        CloseableHttpResponse response = null;
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(urlStr);
        try {
            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(connectTimeout)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(socketTimeout).build();
            httpPost.setConfig(requestConfig);

            // 创建参数队列
            if (MapUtils.isNotEmpty(paramMap)) {
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                for (Map.Entry<String, String> entry : paramMap.entrySet()) {
                    params.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                }

                UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(params, CHARSET);
                httpPost.setEntity(urlEncodedFormEntity);
            }
            //header
            if (MapUtils.isNotEmpty(headerMap)) {
                for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                    httpPost.setHeader(entry.getKey(), entry.getValue());
                }
            }

            //httpPost.setHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
            response = client.execute(httpPost);

            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } finally {
            if (response != null) {
                response.close();
            }
            client.close();
        }
        return "";
    }

    public static String doGet(String urlStr) throws Exception {
        return HttpClientUtil.doGet(urlStr, CONNECTTIMEOUT, SOCKETTIMEOUT, null);
    }

    public static String doGetHeader(String urlStr, Map<String, String> map) throws Exception {
        return HttpClientUtil.doGetHeader(urlStr, CONNECTTIMEOUT, SOCKETTIMEOUT, null, map);
    }


    public static String doGet(String urlStr, int connectTimeout, int socketTimeout, String cookies) throws Exception {

        CloseableHttpResponse response = null;
        CloseableHttpClient client = HttpClients.createDefault();
        //URL url = new URL(urlStr);
        //URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(), url.getQuery(), null);
        HttpGet httpGet = new HttpGet(urlStr);
        try {

            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(connectTimeout)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(socketTimeout)
                    .build();
            httpGet.setConfig(requestConfig);

            String userAgent = "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.87 Safari/537.36";
            httpGet.setHeader("User-Agent", userAgent);
            httpGet.setHeader("Accept", "*/*");


            if (StringUtils.isNotBlank(cookies)) {
                httpGet.setHeader("Cookie", cookies);
            }
            response = client.execute(httpGet);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } catch (Exception e) {
            LOG.error("HttpClientUtil doGet ERROR ,msg = " + e.getMessage(), e);
            throw e;
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    public static String doGetHeader(String urlStr, int connectTimeout, int socketTimeout, String cookies, Map<String, String> map) throws Exception {

        CloseableHttpResponse response = null;
        CloseableHttpClient client = HttpClients.createDefault();
        //URL url = new URL(urlStr);
        //URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(), url.getQuery(), null);
        HttpGet httpGet = new HttpGet(urlStr);
        try {

            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(connectTimeout)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(socketTimeout)
                    .build();
            httpGet.setConfig(requestConfig);

            String userAgent = "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.87 Safari/537.36";
            httpGet.setHeader("User-Agent", userAgent);
            httpGet.setHeader("Accept", "*/*");

            Set<Map.Entry<String, String>> entries = map.entrySet();
            entries.forEach(entry -> {
                httpGet.setHeader(entry.getKey(), entry.getValue());
            });

            if (StringUtils.isNotBlank(cookies)) {
                httpGet.setHeader("Cookie", cookies);
            }
            response = client.execute(httpGet);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } catch (Exception e) {
            LOG.error("HttpClientUtil doGet ERROR ,msg = " + e.getMessage(), e);
            throw e;
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    /**
     * 关闭资源
     *
     * @param response
     * @param client
     */
    public static void closeResource(CloseableHttpResponse response, CloseableHttpClient client) {
        try {
            if (response != null) {
                response.close();
            }
            if (client != null) {

                client.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static CloseableHttpClient getClient() throws Exception {
        // 在调用SSL之前需要重写验证方法&#xff0c;取消检测SSL
        X509TrustManager trustManager = new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] xcs, String str) {
            }

            public void checkServerTrusted(X509Certificate[] xcs, String str) {
            }
        };

        SSLContext ctx = SSLContext.getInstance(SSLConnectionSocketFactory.TLS);
        ctx.init(null, new TrustManager[]{trustManager}, null);
        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(ctx, NoopHostnameVerifier.INSTANCE);
        // 创建Registry
        RequestConfig requestConfig = RequestConfig.custom()
                .setCookieSpec(CookieSpecs.STANDARD_STRICT)
                .setExpectContinueEnabled(Boolean.TRUE)
                .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.DIGEST))
                .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.BASIC)).build();

        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                .register("http", PlainConnectionSocketFactory.INSTANCE)
                .register("https", socketFactory).build();

        // 创建ConnectionManager&#xff0c;添加Connection配置信息
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);

        CloseableHttpClient client = HttpClients.custom()
                .setConnectionManager(connectionManager)
                .setDefaultRequestConfig(requestConfig).build();

        return client;
    }


    public static String doPostJSONMutl(String urlStr, String json, Map<String, String> headerMap) throws Exception {

        CloseableHttpResponse response = null;
        //CloseableHttpClient client = HttpClients.createDefault();
        CloseableHttpClient client = getClient();
        HttpPost httpPost = new HttpPost(urlStr);
        try {
            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(CONNECTTIMEOUT)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(CONNECTTIMEOUT).build();
            httpPost.setConfig(requestConfig);

            // 创建参数队列
            if (StringUtils.isNotBlank(json)) {

                StringEntity stringEntity = new StringEntity(json, CHARSET);
                stringEntity.setContentType("multipart/form-data");
                httpPost.setEntity(stringEntity);
            }
            //header
            if (MapUtils.isNotEmpty(headerMap)) {
                for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                    httpPost.setHeader(entry.getKey(), entry.getValue());
                }
            }

            response = client.execute(httpPost);

            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } catch (Exception e) {
            LOG.error("HttpClientUtil doPostJSON ERROR ,msg = " + e.getMessage(), e);
            throw e;
        } finally {
            if (response != null) {
                LOG.debug("CLOSE RESPONSE.");
                response.close();
            }
        }
        return "";
    }


    public static String doPostParam2(String urlStr, Map<String, String> paramMap, Map<String, String> headerMap, int connectTimeout, int socketTimeout) throws Exception {

        CloseableHttpResponse response = null;
        CloseableHttpClient client = getClient();
        HttpPost httpPost = new HttpPost(urlStr);
        try {
            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(connectTimeout)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(socketTimeout).build();
            httpPost.setConfig(requestConfig);

            // 创建参数队列
            if (MapUtils.isNotEmpty(paramMap)) {
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                for (Map.Entry<String, String> entry : paramMap.entrySet()) {
                    params.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                }

                UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(params, CHARSET);
                httpPost.setEntity(urlEncodedFormEntity);
            }
            //header
            if (MapUtils.isNotEmpty(headerMap)) {
                for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                    httpPost.setHeader(entry.getKey(), entry.getValue());
                }
            }

            //httpPost.setHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
            response = client.execute(httpPost);

            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } finally {
            if (response != null) {
                response.close();
            }
            client.close();
        }
        return "";
    }

    public static String doGet2(String urlStr, int connectTimeout, int socketTimeout, String cookies) throws Exception {

        CloseableHttpResponse response = null;
        CloseableHttpClient client = getClient();
        //URL url = new URL(urlStr);
        //URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(), url.getQuery(), null);
        HttpGet httpGet = new HttpGet(urlStr);
        try {

            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(connectTimeout)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(socketTimeout)
                    .build();
            httpGet.setConfig(requestConfig);

            String userAgent = "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.87 Safari/537.36";
            httpGet.setHeader("User-Agent", userAgent);
            httpGet.setHeader("Accept", "*/*");


            if (StringUtils.isNotBlank(cookies)) {
                httpGet.setHeader("Cookie", cookies);
            }
            response = client.execute(httpGet);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } catch (Exception e) {
            LOG.error("HttpClientUtil doGet ERROR ,msg = " + e.getMessage(), e);
            throw e;
        } finally {
            if (response != null) {
                response.close();
            }
        }
        return "";
    }

    public static String createLinkString(Map<String, String> params) {

        List<String> keyList = new ArrayList<String>(params.keySet());
        Collections.sort(keyList);

        int i = 1;
        StringBuilder prestr = new StringBuilder();
        for (String key : keyList) {
            String value = params.get(key);
            if (i == 1) {// 拼接时，不包括最后一个&字符
                prestr.append(key).append("=").append(value);
            } else {
                prestr.append("&").append(key).append("=").append(value);
            }
            i++;
        }

        return prestr.toString();
    }


    public static String doPostParam3(String urlStr, Map<String, String> paramMap, Map<String, String> headerMap, int connectTimeout, int socketTimeout) throws Exception {

        CloseableHttpResponse response = null;
        CloseableHttpClient client = getClient();
        HttpPost httpPost = new HttpPost(urlStr);
        try {
            RequestConfig requestConfig = RequestConfig
                    .custom()
                    .setConnectTimeout(connectTimeout)
                    .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                    .setSocketTimeout(socketTimeout).build();
            httpPost.setConfig(requestConfig);

            // 创建参数队列
            if (MapUtils.isNotEmpty(paramMap)) {
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                for (Map.Entry<String, String> entry : paramMap.entrySet()) {
                    params.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                }

                UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(params, CHARSET);
                httpPost.setEntity(urlEncodedFormEntity);
            }
            //header
            if (MapUtils.isNotEmpty(headerMap)) {
                for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                    httpPost.setHeader(entry.getKey(), entry.getValue());
                }
            }
            String userAgent = "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.87 Safari/537.36";
            httpPost.setHeader("User-Agent", userAgent);
            httpPost.setHeader("Accept", "*/*");
            httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            httpPost.setHeader("Referer", "https://www.vpay.com/");


            response = client.execute(httpPost);

            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, CHARSET);
            }

        } finally {
            if (response != null) {
                response.close();
            }
            client.close();
        }
        return "";
    }


public static String doGetJson(String urlStr) throws Exception {

    CloseableHttpResponse response = null;
    CloseableHttpClient client = getClient();
    //URL url = new URL(urlStr);
    //URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(), url.getQuery(), null);
    HttpGet httpGet = new HttpGet(urlStr);
    try {
        RequestConfig requestConfig = RequestConfig
                .custom()
                .setConnectTimeout(CONNECTTIMEOUT)
                .setConnectionRequestTimeout(CONNECTIONREQUESTTIMEOUT)
                .setSocketTimeout(SOCKETTIMEOUT)
                .build();
        httpGet.setConfig(requestConfig);
        httpGet.setHeader("Accept", "application/json");
        httpGet.setHeader("Content-Type", "application/json");

        response = client.execute(httpGet);
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            return EntityUtils.toString(entity, CHARSET);
        }

    } catch (Exception e) {
        LOG.error("HttpClientUtil doGet ERROR ,msg = " + e.getMessage(), e);
        throw e;
    } finally {
    	if (response != null) {
            response.close();
        }
    }
    return "";
}
    public static void main(String[] args) {
        try {
            String merchantId = "M00005370";
            String merchantEncryptionKey = "pl0hn8rv2IZ6XY9dz8iO0rs3ra5kr0Cr"; //16 Charachter String
		/*Map<String,String> map = new HashMap<String,String>();
	String dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
	String uniqueOrderId  = new SimpleDateFormat("ddMMYYYY").format(new Date())+System.currentTimeMillis();
	map.put("merchantId", "M00005370");
	map.put("apiKey", "pl0hn8rv2IZ6XY9d");
	map.put("txnId",uniqueOrderId);
	map.put("amount", "100.00");
	map.put("dateTime", dateTime);
	map.put("custMail", "test@test.com");
	map.put("custMobile", "9876543210");
	map.put("returnURL", "https://www.simplyfy.ae/vPay-sdk/pay/notify/onepay/return");
	map.put("isMultiSettlement", "0");
	map.put("productId", "DEFAULT");
	map.put("channelId", "0");
	map.put("txnType", "DIRECT");
	map.put("instrumentId", "NA");
	map.put("cardType", "NA");
	map.put("udf3", "NA");
	map.put("udf1", "NA");
	map.put("udf2", "NA");
	map.put("udf4", "NA");
	map.put("udf5", "NA");
	map.put("cardDetails", "NA");

	String json = JSON.toJSONString(map);


	System.out.println("req json:"+json);
	String ALGO = "AES";
   	byte[] keyByte = merchantEncryptionKey.getBytes();
    Key key = new SecretKeySpec (keyByte, ALGO);
	Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
	byte[] ivByte ="pl0hn8rv2IZ6XY9d".getBytes();
	IvParameterSpec iv = new IvParameterSpec(ivByte);
	c.init(Cipher.DECRYPT_MODE, key,iv);
	byte[] encVal = c.doFinal(json.toString().getBytes());
	byte[] encryptedByteValue =  java.util.Base64.getEncoder().encode(encVal);
	String encryptedRequest = new String(encryptedByteValue);
	System.out.println("json enc data : "+encryptedRequest);
	Map<String,String> reqMap = new HashMap<String,String>();
	reqMap.put("reqData", encryptedRequest);
	reqMap.put("merchantId",merchantId );
	System.out.println("req data: "+reqMap);
	String s = doPostParam("https://pa-preprod.1pay.in/payment/payprocessorV2",reqMap,null);
	System.out.println(s);*/

            //查询
/*	Map<String,String> qreqMap = new HashMap<String,String>();
	qreqMap.put("txnId", "16691164435440016458");
	qreqMap.put("merchantId","M00005370" );
	System.out.println("query req data: "+qreqMap);
	String qs = doPostParam("https://pa-preprod.1pay.in/payment/getTxnDetails",qreqMap,null);
	System.out.println(qs);	*/
            //refund
	/*	String uniqueOrderId  = new SimpleDateFormat("ddMMYYYY").format(new Date())+System.currentTimeMillis();
		Map<String,String> refmap = new HashMap<String,String>();
		refmap.put("merchantId", "M00005370");
		refmap.put("apiKey", "pl0hn8rv2IZ6XY9d");
		refmap.put("txnId","16692041852410016463");
		refmap.put("refundAmount", "10.00");
		refmap.put("refundRequestId", uniqueOrderId);
		refmap.put("addedBy", "merchant");
		String refjson = JSON.toJSONString(refmap);
		System.out.println("req json:"+refjson);
		String ALGO = "AES";
	   	byte[] keyByte = merchantEncryptionKey.getBytes();
	    Key key = new SecretKeySpec (keyByte, ALGO);
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] ivByte =merchantEncryptionKey.substring(0, 16).getBytes();
		IvParameterSpec iv = new IvParameterSpec(ivByte);
		c.init(Cipher.ENCRYPT_MODE, key,iv);
		byte[] encVal = c.doFinal(refjson.toString().getBytes());
		byte[] encryptedByteValue =  java.util.Base64.getEncoder().encode(encVal);
		String encryptedRequest = new String(encryptedByteValue);
		System.out.println("json enc data : "+encryptedRequest);
		Map<String,String> reqMap = new HashMap<String,String>();
		reqMap.put("encData", encryptedRequest);
		reqMap.put("merchantId",merchantId);
		String reqjson =JSON.toJSONString(reqMap);
		System.out.println("req data: "+reqjson);
		String s = doPostJSON("https://pa-preprod.1pay.in/payment/refundRequest",reqjson,null);
		System.out.println(s);
		*/
	/*	String uniqueOrderId  = new SimpleDateFormat("ddMMYYYY").format(new Date())+System.currentTimeMillis();
		Map<String,String> refmap = new HashMap<String,String>();
		refmap.put("merchantId", "M00005370");
		refmap.put("txnId","16691164435440016458");
		refmap.put("refundRequestId", "231120221669204233942");
		String refjson = JSON.toJSONString(refmap);

		System.out.println("req json:"+refjson);
		String ALGO = "AES";
	   	byte[] keyByte = merchantEncryptionKey.getBytes();
	    Key key = new SecretKeySpec (keyByte, ALGO);
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] ivByte =merchantEncryptionKey.substring(0, 16).getBytes();
		IvParameterSpec iv = new IvParameterSpec(ivByte);
		c.init(Cipher.ENCRYPT_MODE, key,iv);
		byte[] encVal = c.doFinal(refjson.toString().getBytes());
		byte[] encryptedByteValue =  java.util.Base64.getEncoder().encode(encVal);
		String encryptedRequest = new String(encryptedByteValue);
		System.out.println("json enc data : "+encryptedRequest);
		Map<String,String> reqMap = new HashMap<String,String>();
		reqMap.put("encData", encryptedRequest);
		reqMap.put("merchantId",merchantId );
		String reqjson =JSON.toJSONString(reqMap);
		System.out.println("req data: "+reqjson);
		String s = doPostJSON("https://pa-preprod.1pay.in/payment/refundStatus",reqjson,null);
		System.out.println(s);*/

            String s = doGet("https://www.albinorecharge.com/api/payout/transaction_status?agentId=0000000004");
            System.out.println(s);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



