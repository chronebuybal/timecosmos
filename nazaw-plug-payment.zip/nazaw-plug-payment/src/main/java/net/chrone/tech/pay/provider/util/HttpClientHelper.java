package net.chrone.tech.pay.provider.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;


public class HttpClientHelper {

    public static final String GET = "GET";
    public static final String POST = "POST";

    public static String getNvPairs(List<String[]> list, String charSet) {
        if (list == null || list.size() == 0) {
            return null;
        }
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < list.size(); i++) {
            String[] nvPairStr = list.get(i);
            try {
                if (i > 0) {
                    stringBuffer.append("&");
                }
                stringBuffer.append(URLEncoder.encode(nvPairStr[0], charSet)).append("=")
                        .append(URLEncoder.encode(nvPairStr[1], charSet));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return null;
            }
        }
        return stringBuffer.toString();
    }

    public static String doGet(String httpurl) {
        HttpURLConnection connection = null;
        InputStream is = null;
        BufferedReader br = null;
        String result = null;// 返回结果字符串
        try {
            // 创建远程url连接对象
            URL url = new URL(httpurl);
            // 通过远程url连接对象打开一个连接，强转成httpURLConnection类
            connection = (HttpURLConnection) url.openConnection();
            // 设置连接方式：get
            connection.setRequestMethod("GET");
            // 设置连接主机服务器的超时时间：15000毫秒
            connection.setConnectTimeout(15000);
            // 设置读取远程返回的数据时间：60000毫秒
            connection.setReadTimeout(60000);
            // 发送请求
            connection.connect();
            // 通过connection连接，获取输入流
            if (connection.getResponseCode() == 200) {
                is = connection.getInputStream();
                // 封装输入流is，并指定字符集
                br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                // 存放数据
                StringBuffer sbf = new StringBuffer();
                String temp = null;
                while ((temp = br.readLine()) != null) {
                    sbf.append(temp);
                    sbf.append("\r\n");
                }
                result = sbf.toString();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            if (null != br) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (null != is) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            connection.disconnect();// 关闭远程连接
        }

        return result;
    }

    public static String doGetALLSuccess(String httpurl) {
        HttpURLConnection connection = null;
        InputStream is = null;
        BufferedReader br = null;
        String result = null;// 返回结果字符串
        try {
            // 创建远程url连接对象
            URL url = new URL(httpurl);
            // 通过远程url连接对象打开一个连接，强转成httpURLConnection类
            connection = (HttpURLConnection) url.openConnection();
            // 设置连接方式：get
            connection.setRequestMethod("GET");
            // 设置连接主机服务器的超时时间：15000毫秒
            connection.setConnectTimeout(15000);
            // 设置读取远程返回的数据时间：60000毫秒
            connection.setReadTimeout(60000);
            // 发送请求
            connection.connect();
            // 通过connection连接，获取输入流
            is = connection.getInputStream();
            // 封装输入流is，并指定字符集
            br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            // 存放数据
            StringBuffer sbf = new StringBuffer();
            String temp = null;
            while ((temp = br.readLine()) != null) {
                sbf.append(temp);
                sbf.append("\r\n");
            }
            result = sbf.toString();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            if (null != br) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (null != is) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            connection.disconnect();// 关闭远程连接
        }

        return result;
    }

    public static String doPostForm(String httpUrl, Map param) {

        HttpURLConnection connection = null;
        InputStream is = null;
        OutputStream os = null;
        BufferedReader br = null;
        String result = null;
        try {

            SslUtils.ignoreSsl();

            URL url = new URL(httpUrl);
            // 通过远程url连接对象打开连接
            connection = (HttpURLConnection) url.openConnection();
            // 设置连接请求方式
            connection.setRequestMethod("POST");
            // 设置连接主机服务器超时时间：15000毫秒
            connection.setConnectTimeout(15000);
            // 设置读取主机服务器返回数据超时时间：60000毫秒
            connection.setReadTimeout(60000);

            // 默认值为：false，当向远程服务器传送数据/写数据时，需要设置为true
            connection.setDoOutput(true);
            // 默认值为：true，当前向远程服务读取数据时，设置为true，该参数可有可无
            connection.setDoInput(true);
            // 设置传入参数的格式:请求参数应该是 name1=value1&name2=value2 的形式。
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // 设置鉴权信息：Authorization: Bearer da3efcbf-0845-4fe3-8aba-ee040be542c0
            // connection.setRequestProperty("Authorization", "Bearer
            // da3efcbf-0845-4fe3-8aba-ee040be542c0");
            // 通过连接对象获取一个输出流
            os = connection.getOutputStream();
            // 通过输出流对象将参数写出去/传输出去,它是通过字节数组写出的(form表单形式的参数实质也是key,value值的拼接，类似于get请求参数的拼接)
            if (param != null && param.size() > 0) {
                os.write(createLinkString(param).getBytes());

            }
            // 通过连接对象获取一个输入流，向远程读取
            if (connection.getResponseCode() == 200) {

                is = connection.getInputStream();
                // 对输入流对象进行包装:charset根据工作项目组的要求来设置
                br = new BufferedReader(new InputStreamReader(is, "UTF-8"));

                StringBuffer sbf = new StringBuffer();
                String temp = null;
                // 循环遍历一行一行读取数据
                while ((temp = br.readLine()) != null) {
                    sbf.append(temp);
                    sbf.append("\r\n");
                }
                result = sbf.toString();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            // 关闭资源
            if (null != br) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != os) {
                try {
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != is) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            // 断开与远程地址url的连接
            connection.disconnect();
        }
        return result;
    }

    public static String createLinkString(Map<String, String> params) {

        List<String> keys = new ArrayList<String>(params.keySet());
        Collections.sort(keys);

        StringBuilder prestr = new StringBuilder();
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = params.get(key);
            if (i == keys.size() - 1) {// 拼接时，不包括最后一个&字符
                prestr.append(key).append("=").append(value);
            } else {
                prestr.append(key).append("=").append(value).append("&");
            }
        }

        return prestr.toString();
    }

    public static String doPost(String httpUrl, String json) {
        try {
            URL url = new URL(httpUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            System.setProperty("https.protocols", "TLSv1,TLSv1.2,TLSv1.1,SSLv3");
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            DataOutputStream requestWriter = new DataOutputStream(connection.getOutputStream());
            requestWriter.writeBytes(json);
            requestWriter.close();
            String responseData = "";
            InputStream is = connection.getInputStream();
            BufferedReader responseReader = new BufferedReader(new InputStreamReader(is));
            responseData = responseReader.readLine();
            responseReader.close();
            return responseData;
        } catch (Exception e) {
            return null;
        }

    }

    /**
     * @param url
     * @param data
     * @return
     * @throws Exception
     */
    public static String postHttpRequest(String url, String data) {
        // 创建链接
        HttpURLConnection hconn = null;
        OutputStream os = null;
        InputStream is = null;
        BufferedReader reader = null;
        String returneddata = "";
        try {
            hconn = (HttpURLConnection) new URL(url).openConnection();
            hconn.setRequestMethod("POST"); // 设置为post请求
            hconn.setDoInput(true);
            hconn.setDoOutput(true);
            hconn.setUseCaches(false);
            hconn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            hconn.setConnectTimeout(30000); // 30s
            hconn.setReadTimeout(30000); // 30s

            os = hconn.getOutputStream();
            byte[] f = data.getBytes("UTF-8");
            os.write(f, 0, f.length);
            os.flush();
            // 接收数据
            int code = hconn.getResponseCode();
            String sCurrentLine = "";
            // url访问成功
            if (code == 200) {
                is = hconn.getInputStream();
                reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                while (null != (sCurrentLine = reader.readLine())) {
                    if (sCurrentLine.length() > 0) {
                        returneddata = returneddata + sCurrentLine.trim();
                    }
                }
            }
            System.out.println("http-code:" + code);

        } catch (Exception e) {

            e.printStackTrace();
        } finally {
            if (hconn != null) {
                hconn.disconnect();
            }
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                    reader = null;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return returneddata;
    }


    public static String postUrlEncodeForm(String url, Map<String, Object> map) throws Exception {

        String coding = "UTF-8";

        //处理请求参数
        List<NameValuePair> valuePairs = new ArrayList<>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            NameValuePair valuePair = new BasicNameValuePair(entry.getKey(), String.valueOf(entry.getValue()));
            valuePairs.add(valuePair);
        }

        //设置client参数
        HttpClient client = HttpClientBuilder.create().build();

        //发送请求
        HttpPost post = new HttpPost(url);
        HttpEntity entity = new UrlEncodedFormEntity(valuePairs, coding);
        post.setEntity(entity);
        HttpResponse response = client.execute(post);

        String result = "";

        //处理响应结果
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode != 200) {
            throw new RuntimeException("statusCode = [" + statusCode + "]");
        } else {
            HttpEntity respEntity = response.getEntity();
            result = EntityUtils.toString(respEntity, coding);
        }

        return result;

    }

    public static void main(String[] args) {
        try {
            /*Map<String, String> map = new HashMap<String, String>();
            String dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            String uniqueOrderId = new SimpleDateFormat("ddMMYYYY").format(new Date()) + System.currentTimeMillis();
            map.put("merchantId", "M0002");
            map.put("apiKey", "jpuT6032");
            map.put("txnId", uniqueOrderId);
            map.put("amount", "10.00");
            map.put("dateTime", dateTime);
            map.put("custMail", "test@test.com");
            map.put("custMobile", "9876543210");
            map.put("returnURL", "https://www.vpay.com/notify");
            map.put("isMultiSettlement", "0");
            map.put("productId", "DEFAULT");
            map.put("channelId", "0");
            map.put("txnType", "DIRECT");
            map.put("instrumentId", "NA");
            map.put("cardType", "NA");
            map.put("udf3", "NA");
            map.put("udf1", "NA");
            map.put("udf2", "NA");
            map.put("udf4", "NA");
            map.put("udf5", "NA");
            map.put("cardDetails", "NA");

            String json = JSON.toJSONString(map);

            String merchantId = "M0002";
            String merchantEncryptionKey = "jpuT6032jpuT6032"; //16 Charachter String
            System.out.println("加密前json:" + json);
            String ALGO = "AES";
            byte[] keyByte = merchantEncryptionKey.getBytes();
            Key key = new SecretKeySpec(keyByte, ALGO);
            Cipher c = Cipher.getInstance(ALGO);
            c.init(Cipher.ENCRYPT_MODE, key);
            byte[] encVal = c.doFinal(json.toString().getBytes());
            byte[] encryptedByteValue = java.util.Base64.getEncoder().encode(encVal);
            String encryptedRequest = new String(encryptedByteValue);
            System.out.println("json加密后: " + encryptedRequest);

            Map<String, String> reqMap = new HashMap<String, String>();
            reqMap.put("reqData", encryptedRequest);
            reqMap.put("merchantId", merchantId);
            System.out.println("发送内容: " + reqMap);
            String s = doPostForm("https://onepaypgtest.in/onepayVAS/payprocessor", reqMap);
            System.out.println(s);*/
        	String s = doPost("https://www.albinorecharge.com/api/payout/transaction_status?agentId=0000000004",null);
        	System.out.println(s);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
