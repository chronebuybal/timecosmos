package net.chrone.tech.pay.provider.util;

import okhttp3.*;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Key;

public class AESUtil {
    private static final String KEY_ALGORITHM = "AES";

    private static final String AES128CBC = "AES/CBC/PKCS5Padding";

    public static byte[] encrypt(String data, String key, String iv) throws Exception {
        return encrypt(data.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8), iv.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * 加密
     *
     * @param data 待加密数据
     * @param key  密钥
     * @return byte[] 加密数据
     * @throws Exception
     */
    public static byte[] encrypt(byte[] data, byte[] key, byte[] iv) throws Exception {
        Key k = new SecretKeySpec(key, KEY_ALGORITHM);
        Cipher cipher = Cipher.getInstance(AES128CBC);
        final IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, k, ivParameterSpec);
        return cipher.doFinal(data);
    }

    public static String doPost(String url, String data, Headers headers) throws IOException {
        OkHttpClient customClient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .headers(headers)
                .post(RequestBody.create(MediaType.parse("application/json;charset=UTF-8"), data))
                .build();
        Response response = customClient.newCall(request).execute();
        String resp = response.body().string();
        return resp;
    }
}
