package net.chrone.tech.pay.provider.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.Format;
import java.util.ResourceBundle;


import com.alibaba.fastjson.JSON;

public class SdkUtil {
	
	private final static String FILE = "payment";

	/**
	 * 计算手续费
	 * @param amount
	 * @param feeRate
	 * @return
	 */
	public static int caclFee(int amount,double feeRate){
		double fee = amount*feeRate;
		BigDecimal bigDecimal = new BigDecimal(fee);
		int intFee = bigDecimal.setScale(0, BigDecimal.ROUND_HALF_UP).intValue();
		return intFee;
	}
	
	public static String fen2yuan(Integer amount){
		if (amount == null) {
			return "0.00";
		}
		DecimalFormat df = new DecimalFormat("0.00");
		double d = amount / 100d;
		String s = df.format(d);
		return s;   
	}
	
	public static String fen2yuan(Long amount){
		if (amount == null) {
			return "0.00";
		}
		DecimalFormat df = new DecimalFormat("0.00");
		double d = amount / 100d;
		String s = df.format(d);
		return s;   
	}
	
	public static String getStringValue(String key){
		ResourceBundle resource = ResourceBundle.getBundle(FILE);
		return resource.getString(key);
	}
	
	public static Integer getIntValue(String key){
		return Integer.valueOf(getStringValue(key));
	}
	
	
	public static int randNum() {
		return (int)(Math.random()*100);
	}
	
	public static int yuan2Fen(String yuan) {
	     BigDecimal var1 = new BigDecimal(yuan);
	     BigDecimal var2 = new BigDecimal(100);
	     BigDecimal var3 = var1.multiply(var2);
	     int value = Integer.parseInt(var3.stripTrailingZeros().toPlainString());
	    return value;
	}
	public static Long yuan2FenLong(String yuan) {
	     BigDecimal var1 = new BigDecimal(yuan);
	     BigDecimal var2 = new BigDecimal(100);
	     BigDecimal var3 = var1.multiply(var2);
	     Long value = Long.parseLong(var3.stripTrailingZeros().toPlainString());
	    return value;
	}
	
	
	public static String format(String num, int length) {
		if (null==num) return "";
		StringBuffer sb = new StringBuffer();
		String s = ""+num;
		if (s.length()<length) {
			int addNum = length-s.length();
			for (int i=0;i<addNum;i++) {
				sb.append("0");
			}
			sb.append(s);
		} else {
			return s.substring(s.length()-length,s.length());
		}
		return sb.toString();
	}
	

	public static String format1(String num, int length) {
		if (null==num) return "";
		StringBuffer sb = new StringBuffer();
		String s = ""+num;
		if (s.length()<length) {
			int addNum = length-s.length();
			sb.append(s);
			for (int i=0;i<addNum;i++) {
				sb.append("0");
			}
		} else {
			return s.substring(s.length()-length,s.length());
		}
		return sb.toString();
	}

}
