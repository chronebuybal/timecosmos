package net.chrone.tech.pay.provider.handler;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.chrone.tech.pay.provider.util.SdkUtil;

/**
 * 业务处理工厂类
 * @author Administrator
 *
 */
public class PaymentBusinessHandlerFactory {
	static final Logger log = LoggerFactory.getLogger(PaymentBusinessHandlerFactory.class);

	public static PaymentBusinessHandler getInstance(String netId,String funCode) {
		if (StringUtils.isEmpty(funCode)) {
			log.error("参数错误：funCode="+funCode);
			return null;
		}
		// 从配置文件获得业务处理类
		String busiClassName ="";
		try {
			busiClassName=SdkUtil.getStringValue("payment.busi."+funCode+"."+netId);
			if (StringUtils.isEmpty(busiClassName)) {
				log.error("配置错误：funCode="+funCode+",busiClassName="+busiClassName);
				return null;
			}
		} catch (Exception e) {
			log.error("配置错误：funCode="+funCode+",busiClassName="+busiClassName);
			return null;
		}
	
		
		//
		PaymentBusinessHandler bh = null;
		try {
			Class c = Class.forName(busiClassName);
			Object obj = c.newInstance();
			bh = (PaymentBusinessHandler)obj;
		} catch (ClassNotFoundException e) {
			log.error("实例化业务处理类异常：funCode="+funCode+",busiClassName="+busiClassName, e);
			return null;
		} catch (InstantiationException e) {
			log.error("实例化业务处理类异常：funCode="+funCode+",busiClassName="+busiClassName, e);
			return null;
		} catch (IllegalAccessException e) {
			log.error("实例化业务处理类异常：funCode="+funCode+",busiClassName="+busiClassName, e);
			return null;
		}
		return bh;
	}
}
