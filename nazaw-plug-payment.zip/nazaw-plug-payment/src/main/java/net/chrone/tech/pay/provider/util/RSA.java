package net.chrone.tech.pay.provider.util;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * 
 * @author alphaDo
 *
 */
public class RSA {

	private static final String KEY_ALGORITHM = "RSA";
	private static final int KEY_SIZE = 2048;//设置长度
	private static final String PUBLIC_KEY = "publicKey";
	private static final String PRIVATE_KEY = "privateKey";
	public static final String SIGNATURE_ALGORITHM = "SHA256withRSA";
	
	/**
	 * 签名
	 * @param key	私钥
	 * @param requestData	请求参数
	 * @return
	 */
	public static String sign(byte[] data, String privateKey) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        PrivateKey privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initSign(privateK);
        signature.update(data);
        return Base64.encodeBase64String(signature.sign());
    }
	

	public static boolean verifySign(String key, String requestData, String signature){
		boolean verifySignSuccess = false;
		try {
			PublicKey publicKey = getPublicKey(key);
			
			Signature verifySign = Signature.getInstance(SIGNATURE_ALGORITHM);
			verifySign.initVerify(publicKey);
			verifySign.update(requestData.getBytes());
			
			verifySignSuccess = verifySign.verify(Base64.decodeBase64(signature));
			System.out.println("===验签结果："+verifySignSuccess);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return verifySignSuccess;
	}
	public static PublicKey getPublicKey(String key) {
	    try {
	        byte[] byteKey = Base64.decodeBase64(key);
	        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(byteKey);
	        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
	        return keyFactory.generatePublic(x509EncodedKeySpec);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    
	    return null;
	}
	public static void main(String[] args) throws Exception {
		String privateKey ="MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCmadC0M4fsw2CIHYbZUwbXrRBlJK8QETp5NDZI58VHZN15att5YvrS6oB+C7NWt+5EY5EcCJ8rjqo+rxbH4X7SAzm5vt+IqPJ6q1MJu/DljgLtntyig5KLWOSbxNFTxowVNAtF0JtOl4k/EWlDemd8fAS1sb8tzxi/h/XeNeb8HapbAVT7YN31CwS/iZha96FjvoJOZAWI05i+3d4GrXGDBhJqhPRtDJgyrbNqMOy0LqqfD7ndRgRikWatYY4UDcAOkU5rGcH2pkD0grsrhvpSEOUlZnmqe8R3w+P1Vtwx5uBqD7PwXzl++IiQ1joDMHykxqZD+ekGasdy0hRPtDE/AgMBAAECggEAdVR/6L24ZS9vnSisTgfi+Ce2Oom9wGdVQeWVLJv1FRxBpvy3V4N480KRa81WGZs/LArDYe+WQgCped67Ahyz7OCHT7YLJvBvXhvzRRa0hzU0TVNHnnGD3inDrSv8psODOuPh2sx049ml08iz3fashjFupKh48ZRlj40Nxilc/X3NKeST0NU/IhO49yRO5lRWV9ebkNjxpTb+tVTv4QvobQBhqPQl/52VRmsx7D1OXwl5WvqH635I7x8HXmrJ8BjyXQvo9jO0ewLeWuqUq45iCmlAdxqplMqxuxikWTmBQhWr8RkszG6KKWn/fzWVfem2yTRCdnXMleO3eML498MEWQKBgQDeLmrjXpznKDzHgcFo0NYM4GMTSETFmfIoCpUTloTbpcsYZf7u7WTZYj/CEEw3LXVhPFe3tR5nC7LmZQI1h2RbvPhNpr1g7qwcrLm8GlD/PrB5jFcrtyEC1/v3Twx6ahj8Lorr0qHRsLaI7RrxmshrpU2l6E2M7JQPArv3ld0VVQKBgQC/vlOKeZK/+Lf+p0onsOUuhsrbj6a8FaMNMBQVuaP53emz17FNbfNo341FbZlTFxDSLaYlqKvvugeGMn+fI41REmMUUALa9TL7p5llgaDmQaXB9qPaNiWM0iJx1rrnCagP88E0YvmWGb+1SxeTF/uKFj40Rapyt9W/uH1q+nksQwKBgCarEXNM7iXU/O8ECDND1V0cWGHsu/tgFaMeZF+qXKkVq8ktRzcyHdEvpkUSLRGVWc54gBO68/WfNZ2fisjiLXdB5j0tfdw27cF31kOEmQAzWudso2c6UgZ6rKGYImXTvVF2kDsGx58FEF+4VG4kMCl79Y2gZo7WRdZu9WPbs0SZAoGBAKhQcVMYHyrnMNSYky6+SKAL8NzFf+6Q671y296qQ/fdxf15tIksoEQKIR+18qaOk9R7/+IE61EXsu0pPQA8HBvzkQfOqIL+RM/FspD5Nn2JWPEoCXNOnq279EKL5StUPbQrHAlZbJBHcBK7pSkZH1R67AXEtbfYCgku8OFMl7uzAoGBAMPeSQhvdVcUa5jXxgVFICE/1HKhyzdPQlWEK2mJiXsg7drGmJSlr0Hipl1gxB3Vx4n8RTeLWbhmC19TuKxB9ySDW/0+U2lhJl+mCweVIv4CaGjR4NM06VpdFnEI5gnLvb0ENidEYZoqUMNZ3ds7XA2qmPzyAq/h52GlO6JaCpyn";
		 System.out.println(sign("test".getBytes(),privateKey)); 
		 String s ="{'mhtOrderTimeOut':'3600','mhtOrderType':'01','mhtCharset':'UTF-8','mhtOrderNo':'16817314740820018716','appId':'000110008409871','mhtOrderAmt':'1000','signType':'RSA2','nowPayOrderNo':'2304171938038467896','mhtOrderName':'test','mhtOrderStartTime':'20230417193803','transStatus':'A001','mhtCurrencyType':'INR'}";
	     String sign ="QGGEXQoNiqLgm/g0WLHM0x6x6nUTPFYA4r01d838gaGkYdtjUBwbg4MxfPcAf3xk8D7a1Fba3BqnZKOYjKqSsjpPsnuiz/IBS6O2oS7p2aJ+J1KFQ8lQ/Xtycw1LFPMwl6T/XJQSjhDThvDYSXzTWtdtm/GdRKaE+i23VQLN96EIAHcijJWFG8M7gSzJ5VEqh9QrO8P03G7xsDjX1M0nkDllAcmgOCiRvc1s5Q99EsSz34OTG/yEyYYVkiTv+FZ7s1XSuKH/yW2MCE73rYICSZhvROWtOtWhuCrjs/yAqTjhNTsYnfCBcEu/DRYz0ed/bT4VStJclOW8UN7CrAQq1g==";
	     String pubKey ="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkDbcCDfL1NzXhttg96cGEUVisIoFuCO8oS12f9Aap990JAQII0NMqWYNmxolwf/5sGv0mina44hNjRrMfVhhBVc99dNGwRUzVZ9FrJfgD+OtaHIDslBt1zpUOGIMGhYzUnhtnX26/NOql88fmOkfO5E/42om0gAeerbeucMLIn1cC4W6K/EEvmPbX+IL0YH/z8RDDBdmqZfXcXixQdvTMCzZ6sTiOazuj673Qxc8xufgjHmQtN0bmHkt5UwaFDnKQJk9ZZCnsVbx+Q3keDT/9gyzdEP0Va48gm3PDSrnX5/ia1pkJ4cGvbpsdepzkafenLF+WB13s998rjWT5tm8MwIDAQAB";
	   
	     System.out.println(verifySign(pubKey,s,sign));
	     
	}
	  
}
