package net.chrone.tech.pay.provider.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.DigestUtils;

import com.alibaba.fastjson.JSON;

import cn.hutool.core.util.HexUtil;


/**
 * 服务端签名工具类
 * @author Jerry.Zhang
 *
 */
public class SignatureUtil {
	static final Logger log = LoggerFactory.getLogger(SignatureUtil.class);
	/**
	 * 根据订单信息算签名
	 * @param appKey
	 * @param order
	 * @return
	 */
	public static String doSign(String mchntKey, Object obj) {
		if(null==obj)return null;
		String jsonStr =JSON.toJSONString(obj);
		Map<String, Object> map =JSON.parseObject(jsonStr, Map.class);
		return doEncrypt(map,mchntKey);
		
	}
	
	public static String doEncrypt(Map<String, Object> map,String mchntKey) {
		map.remove("signature");
		map.remove("sign");
		Object[] keys =  map.keySet().toArray();
		Arrays.sort(keys);
		StringBuilder originStr = new StringBuilder();
		for(Object key:keys){
			if(null==map.get(key)){
				continue;
			}
			String value =""+map.get(key);
			if(StringUtils.isEmpty(value)){
				continue;
			}
			originStr.append(key).append("=").append(map.get(key)).append("&");
		}
		originStr.append("key=").append(mchntKey);
		String sign = DigestUtils.md5DigestAsHex(originStr.toString().getBytes());
		return sign;
	}
	
	public static String doSignEncrypt(Map<String, String> map,String mchntKey) {
		map.remove("signature");
		map.remove("sign");
		Object[] keys =  map.keySet().toArray();
		Arrays.sort(keys);
		StringBuilder originStr = new StringBuilder();
		for(Object key:keys){
			if(null==map.get(key)){
				continue;
			}
			String value =""+map.get(key);
			if(StringUtils.isEmpty(value)){
				continue;
			}
			originStr.append(key).append("=").append(map.get(key)).append("&");
		}
		originStr.append("key=").append(mchntKey);
		String sign = DigestUtils.md5DigestAsHex(originStr.toString().getBytes());
		System.out.println(originStr);
		return sign;
	}
	
	public static void main(String[] args) {
		/*Map<String,Object> map = new HashMap<String,Object>();
		map.put("amount", "22800");
		map.put("source", "0");
		map.put("mchntOrderNo", "151237324725600000002");
		map.put("notifyUrl", "http://127.0.0.1:8080//credit-pay-api//notify//upLevelOrder");
		map.put("subject", "会员升级");
		map.put("clientIp", "124.65.118.126");
		map.put("body", "会员升级");
		map.put("appid", "0000005006");
		System.out.println(getSignStr(map,""));*/
		
		System.out.println(getFinoPaySign("aaa","680e8aff69384ae1a197b981e278069a"));
	}
	/**
	 * check sign
	 * @param appKey
	 * @param map
	 * @return
	 */
	public static boolean check(String appKey,Map<String,Object> map){
		String signature = (String)map.get("signature");
		map.remove("signature");
		String localSign = doEncrypt(map,appKey);
		return signature.equalsIgnoreCase(localSign);
	}
	
	
	  /**
     * <p><b>Description: </b>计算签名摘要
     * <p>2018年9月30日 上午11:32:46
     * @param map 参数Map
     * @param key 商户秘钥
     * @return
     */
    public static String getSign(Map<String,Object> map, String key){
        ArrayList<String> list = new ArrayList<String>();
        for(Map.Entry<String,Object> entry:map.entrySet()){
            if(null != entry.getValue() && !"".equals(entry.getValue())){
                list.add(entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        int size = list.size();
        String [] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < size; i ++) {
            sb.append(arrayToSort[i]);
        }
        String result = sb.toString();
        result += "key=" + key;
        log.info("签名原串："+result);
        result = md5(result, "UTF-8").toUpperCase();
        return result;
    }
    
	  /**
     * <p><b>Description: </b>计算签名摘要
     * <p>2018年9月30日 上午11:32:46
     * @param map 参数Map
     * @param key 商户秘钥
     * @return
     */
    public static String getAmmcinrSign(Map<String,Object> map, String key){
        ArrayList<String> list = new ArrayList<String>();
        for(Map.Entry<String,Object> entry:map.entrySet()){
            if(null != entry.getValue() && !"".equals(entry.getValue())){
                list.add(entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        int size = list.size();
        String [] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < size; i ++) {
            sb.append(arrayToSort[i]);
        }
        String result = sb.toString();
        result += "secret_key=" + key;
        log.info("签名原串："+result);
        result = md5(result, "UTF-8").toLowerCase();
        return result;
    } 
    

    /**
     * <p><b>Description: </b>MD5
     * <p>2018年9月30日 上午11:33:19
     * @param value
     * @param charset
     * @return
     */
    public static String md5(String value, String charset) {
        MessageDigest md = null;
        try {
            byte[] data = value.getBytes(charset);
            md = MessageDigest.getInstance("MD5");
            byte[] digestData = md.digest(data);
            return toHex(digestData);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String toHex(byte input[]) {
        if (input == null) {
            return null;
        }
        StringBuffer output = new StringBuffer(input.length * 2);
        for (int i = 0; i < input.length; i++) {
            int current = input[i] & 0xff;
            if (current < 16) {
                output.append("0");
            }
            output.append(Integer.toString(current, 16));
        }

        return output.toString();
    }

	  /**
     * <p><b>Description: </b>计算签名摘要
     * <p>2018年9月30日 上午11:32:46
     * @param map 参数Map
     * @param key 商户秘钥
     * @return
     */
    public static String getSignStr(Map<String,Object> map,String key){
        ArrayList<String> list = new ArrayList<String>();
        int num =0;
        for(Map.Entry<String,Object> entry:map.entrySet()){
            if(null != entry.getValue() && !"".equals(entry.getValue())){
            		 list.add(entry.getKey() + "=" + entry.getValue());
               }
        }
        int size = list.size();
        String [] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < size; i ++) {
        	if(num==0) {
        		  sb.append(arrayToSort[i]);
        	}else {
        		  sb.append("&");
        		  sb.append(arrayToSort[i]);
        	}
        	num++;
        }
        String result = sb.toString();
        log.info("签名原串："+result);
        return result;
    }
    public static String getRandomValue(int length){
        String charSet = "abcdefghijklmnopqrstuvwxyz";
        SecureRandom random = new SecureRandom();
        StringBuilder value = new StringBuilder(length);
        for (int i = 0; i < length; i++){
            value.append(charSet.charAt(random
                    .nextInt(charSet.length())));
        }
        return value.toString();
    }
    
    
    /**
     * <p><b>Description: </b>计算签名摘要
     * <p>2018年9月30日 上午11:32:46
     * @param map 参数Map
     * @param key 商户秘钥
     * @return
     */
    public static String getBzPaySign(String str, String key){
    	String signatureMethodValue = "HmacSHA256";
    	try {
    		Mac hmacSha256 = Mac.getInstance(signatureMethodValue);
        	SecretKeySpec secKey = new SecretKeySpec(key.getBytes("utf-8"), signatureMethodValue);
        	hmacSha256.init(secKey);
        	byte[] hash = hmacSha256.doFinal(str.getBytes("utf-8"));
        	//最后将签名数据转为16进制字符串，并转为大写
        	//HexUtil.encodeHexSt() 方法为byte转hex16示例方法，具体请自行实现
        	String signature =HexUtil.encodeHexStr(hash).toUpperCase();
        	return signature;
		} catch (Exception e) {
		  e.printStackTrace();
		}
    	return null;
    
    }
    
    /**
     * <p><b>Description: </b>计算签名摘要
     * <p>2018年9月30日 上午11:32:46
     * @param map 参数Map
     * @param key 商户秘钥
     * @return
     */
    public static String getFinoPaySign(String str, String key){
    	String signatureMethodValue = "HmacSHA256";
    	try {
    		Mac hmacSha256 = Mac.getInstance(signatureMethodValue);
        	SecretKeySpec secKey = new SecretKeySpec(key.getBytes("utf-8"), signatureMethodValue);
        	hmacSha256.init(secKey);
        	byte[] hash = hmacSha256.doFinal(str.getBytes("utf-8"));
        	//最后将签名数据转为16进制字符串，并转为大写
        	//HexUtil.encodeHexSt() 方法为byte转hex16示例方法，具体请自行实现
        	String signature =HexUtil.encodeHexStr(hash).toLowerCase();
        	return signature;
		} catch (Exception e) {
		  e.printStackTrace();
		}
    	return null;
    
    }
    
	public static String doHaYuEncrypt(Map<String, Object> map,String mchntKey) {
		map.remove("sign");
		Object[] keys =  map.keySet().toArray();
		Arrays.sort(keys);
		StringBuilder originStr = new StringBuilder();
		for(Object key:keys){
			if(null==map.get(key)){
				continue;
			}
			String value =""+map.get(key);
			if(StringUtils.isEmpty(value)){
				continue;
			}
			originStr.append(key).append("=").append(map.get(key)).append("&");
		}
		originStr.append("signKey=").append(mchntKey);
		log.info("singStr:"+originStr);
		String sign = DigestUtils.md5DigestAsHex(originStr.toString().getBytes());
		return sign;
	}
	
}
