package net.chrone.tech.pay.provider.util;

public class ResultConstant {
	public static String ERROR_0017="0017";
	public static String ERROR_0017_MSG="PayChannel undefined";
}
