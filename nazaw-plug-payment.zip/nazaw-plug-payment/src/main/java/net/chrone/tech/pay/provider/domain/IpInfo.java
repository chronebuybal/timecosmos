package net.chrone.tech.pay.provider.domain;

public class IpInfo {

	private String countryName;
	private String countryNameCn;
	private String provinceName;
	private String provinceNameCn;
	private String cityName;
	private String cityNameCn;
	private Double latitude;
	private Double longitude;
	
	public String getProvinceNameCn() {
		return provinceNameCn;
	}
	public void setProvinceNameCn(String provinceNameCn) {
		this.provinceNameCn = provinceNameCn;
	}
	public String getProvinceName() {
		return provinceName;
	}
	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCountryNameCn() {
		return countryNameCn;
	}
	public void setCountryNameCn(String countryNameCn) {
		this.countryNameCn = countryNameCn;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCityNameCn() {
		return cityNameCn;
	}
	public void setCityNameCn(String cityNameCn) {
		this.cityNameCn = cityNameCn;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	@Override
	public String toString() {
		return "IpInfo [countryName=" + countryName + ", countryNameCn=" + countryNameCn + ", provinceName="
				+ provinceName + ", provinceNameCn=" + provinceNameCn + ", cityName=" + cityName + ", cityNameCn="
				+ cityNameCn + ", latitude=" + latitude + ", longitude=" + longitude + "]";
	}
	
}
