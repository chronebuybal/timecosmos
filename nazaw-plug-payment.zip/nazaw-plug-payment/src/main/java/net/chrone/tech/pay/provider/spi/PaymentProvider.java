package net.chrone.tech.pay.provider.spi;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.chrone.tech.pay.provider.PayProvider;
import net.chrone.tech.pay.provider.handler.PaymentBusinessHandler;
import net.chrone.tech.pay.provider.handler.PaymentBusinessHandlerFactory;
import net.chrone.tech.pay.provider.util.ResultConstant;

/**
 * 支付宝APP支付
 * 
 * @author zhaojing
 *
 */
public class PaymentProvider implements PayProvider {

	@Override
	public Map<String, Object> doPaymentService(Map<String, Object> reqMap) {
		final Logger logger = LoggerFactory.getLogger(PaymentProvider.class);
		/**
		 * 执行银行前置服务
		 * 
		 * @param reqJson
		 * @return
		 */
		// 业务处理代码
		String netType = (String) reqMap.get("payChannelId"); // 收单渠道ID
		String funCode = (String) reqMap.get("funCode"); // 交易类型
		PaymentBusinessHandler bHandler ;
		try {
			bHandler= PaymentBusinessHandlerFactory.getInstance(netType, funCode);
			if (bHandler == null) {
				return encodeMessage(null, ResultConstant.ERROR_0017, ResultConstant.ERROR_0017_MSG);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return encodeMessage(null, ResultConstant.ERROR_0017, ResultConstant.ERROR_0017_MSG);
		}
		// 执行业务处理
		Map resMap = bHandler.doBusiness(reqMap);
		// 转换业务处理响应
		logger.info("银行前置:业务处理响应："+resMap);
		return resMap;
	}

	private Map<String, Object> encodeMessage(Map resMap, String errorCode, String errorMsg) {
		if (resMap == null) {
			resMap = new HashMap();
		}
		resMap.put("errorCode", errorCode);
		resMap.put("errorMsg", errorMsg);
		return resMap;
	}

}
