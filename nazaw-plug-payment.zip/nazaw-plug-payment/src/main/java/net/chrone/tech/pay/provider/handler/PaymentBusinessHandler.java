package net.chrone.tech.pay.provider.handler;

import java.util.Map;

/**
 * 业务处理接口
 * @author Administrator
 *
 */
public interface PaymentBusinessHandler {
	/**
	 * 业务处理方法
	 * @param reqMap
	 * @return
	 */
	public Map<String, Object> doBusiness(Map<String, Object> reqMap);
	
}
