package net.chrone.tech.pay.provider.spi;

import java.io.File;
import java.net.InetAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.maxmind.db.CHMCache;
import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.record.City;
import com.maxmind.geoip2.record.Country;
import com.maxmind.geoip2.record.Location;
import com.maxmind.geoip2.record.Subdivision;
import net.chrone.tech.pay.provider.IpProvider;
import net.chrone.tech.pay.provider.domain.IpInfo;
import net.chrone.tech.pay.provider.util.SdkUtil;

/**
 * 支付宝APP支付
 * 
 * @author zhaojing
 *
 */
public class IpProviderImpl implements IpProvider {
	static final Logger logger = LoggerFactory.getLogger(IpProviderImpl.class);

	@Override
	public IpInfo getProvByIp(String ip) {
		IpInfo ipInfo = new IpInfo();
		DatabaseReader reader = null;
		try {
			File database = new File(SdkUtil.getStringValue("ip_db_path"));
			reader = new DatabaseReader.Builder(database).withCache(new CHMCache()).build();
			
			CityResponse response = reader.city(InetAddress.getByName(ip));
			//
			Country country = response.getCountry();

			// province
			Subdivision subdivision = response.getMostSpecificSubdivision();

			City city = response.getCity();

			Location location = response.getLocation();
			
			String countryName = country.getName();
			String countryNameCn = country.getNames().get("zh-CN");
			
			String provinceName = subdivision.getName();
			String provinceNameCn = subdivision.getNames().get("zh-CN");
			
			String cityName = city.getName();
			String cityNameCn = city.getNames().get("zh-CN");
			
			ipInfo.setCountryName(countryName == null ? "" : countryName);
			ipInfo.setCountryNameCn(countryNameCn == null ? "" : countryNameCn);

			ipInfo.setProvinceName(provinceName == null ? "" : provinceName);
			ipInfo.setProvinceNameCn(provinceNameCn  == null ? "" :  provinceNameCn);

			ipInfo.setCityName(cityName == null ? "" : cityName);
			ipInfo.setCityNameCn(cityNameCn == null ? "" :cityNameCn);

			ipInfo.setLatitude(location.getLatitude());
			ipInfo.setLongitude(location.getLongitude());

		} catch (Exception e) {
			logger.error("get ip ERROR,msg:" + e.getMessage(), e);
		}
		return ipInfo;
	}



}
